import { describe, it, expect, beforeEach } from 'vitest';
import { MockRepository } from '@/lib/db/mock-repository';
import type { Product } from '@/lib/types';

const testProducts: Product[] = [
  { id: 'p1', name: 'Earbuds', description: 'Good', price_paise: 499900, stock_status: 'in_stock', image_url: 'https://example.com/1.jpg', active: true, created_at: '2024-01-01', updated_at: '2024-01-01' },
  { id: 'p2', name: 'Watch', description: 'Good', price_paise: 249900, stock_status: 'in_stock', image_url: 'https://example.com/2.jpg', active: true, created_at: '2024-01-01', updated_at: '2024-01-01' },
  { id: 'p3', name: 'Speaker', description: 'Good', price_paise: 199900, stock_status: 'out_of_stock', image_url: 'https://example.com/3.jpg', active: true, created_at: '2024-01-01', updated_at: '2024-01-01' },
  { id: 'p4', name: 'Inactive Item', description: 'Old', price_paise: 99900, stock_status: 'in_stock', image_url: 'https://example.com/4.jpg', active: false, created_at: '2024-01-01', updated_at: '2024-01-01' },
];

function computeTotal(items: { productId: string; quantity: number }[], products: Product[]): number {
  const map = new Map(products.map((p) => [p.id, p]));
  return items.reduce((sum, i) => {
    const p = map.get(i.productId);
    return sum + (p?.price_paise ?? 0) * i.quantity;
  }, 0);
}

function validateCartItems(items: { productId: string; quantity: number }[], products: Product[]): { ok: boolean; error?: string } {
  const map = new Map(products.map((p) => [p.id, p]));
  for (const item of items) {
    if (!item.productId) return { ok: false, error: 'unknown_product' };
    if (!map.has(item.productId)) return { ok: false, error: 'unknown_product' };
    if (item.quantity < 1) return { ok: false, error: 'invalid_quantity' };
    if (item.quantity > 10) return { ok: false, error: 'max_quantity_exceeded' };
  }
  for (const item of items) {
    const p = map.get(item.productId)!;
    if (!p.active) return { ok: false, error: 'inactive_product' };
    if (p.stock_status === 'out_of_stock') return { ok: false, error: 'out_of_stock' };
  }
  return { ok: true };
}

describe('checkout total calculation', () => {
  it('sums server-side prices correctly', () => {
    const items = [
      { productId: 'p1', quantity: 2 },
      { productId: 'p2', quantity: 1 },
    ];
    expect(computeTotal(items, testProducts)).toBe(499900 * 2 + 249900);
  });

  it('handles single item', () => {
    expect(computeTotal([{ productId: 'p1', quantity: 1 }], testProducts)).toBe(499900);
  });

  it('returns 0 for empty cart', () => {
    expect(computeTotal([], testProducts)).toBe(0);
  });

  it('ignores unknown products in total (but validation catches them first)', () => {
    const items = [{ productId: 'nonexistent', quantity: 1 }];
    expect(computeTotal(items, testProducts)).toBe(0);
  });
});

describe('checkout validation rejections', () => {
  it('rejects unknown product', () => {
    const result = validateCartItems([{ productId: 'nonexistent', quantity: 1 }], testProducts);
    expect(result.ok).toBe(false);
    expect(result.error).toBe('unknown_product');
  });

  it('rejects out-of-stock product', () => {
    const result = validateCartItems([{ productId: 'p3', quantity: 1 }], testProducts);
    expect(result.ok).toBe(false);
    expect(result.error).toBe('out_of_stock');
  });

  it('rejects inactive product', () => {
    const result = validateCartItems([{ productId: 'p4', quantity: 1 }], testProducts);
    expect(result.ok).toBe(false);
    expect(result.error).toBe('inactive_product');
  });

  it('rejects quantity below 1', () => {
    const result = validateCartItems([{ productId: 'p1', quantity: 0 }], testProducts);
    expect(result.ok).toBe(false);
    expect(result.error).toBe('invalid_quantity');
  });

  it('rejects quantity above 10', () => {
    const result = validateCartItems([{ productId: 'p1', quantity: 11 }], testProducts);
    expect(result.ok).toBe(false);
    expect(result.error).toBe('max_quantity_exceeded');
  });

  it('accepts valid in-stock items', () => {
    const result = validateCartItems([{ productId: 'p1', quantity: 2 }, { productId: 'p2', quantity: 3 }], testProducts);
    expect(result.ok).toBe(true);
  });
});

describe('mock-pay ownership and state', () => {
  let repo: MockRepository;

  beforeEach(() => {
    repo = new MockRepository();
  });

  it('updates order to paid on successful mock payment', async () => {
    const order = await repo.createOrder({
      userId: 'u1',
      totalPaise: 499900,
      providerOrderId: 'mock_123',
      items: [{ productId: 'p1', nameSnapshot: 'Earbuds', pricePaiseSnapshot: 499900, quantity: 1 }],
    });
    await repo.updateOrderStatus(order.id, 'paid');
    const fetched = await repo.getOrderById(order.id);
    expect(fetched!.status).toBe('paid');
  });

  it('updates order to failed on failed mock payment', async () => {
    const order = await repo.createOrder({
      userId: 'u1',
      totalPaise: 499900,
      providerOrderId: 'mock_123',
      items: [{ productId: 'p1', nameSnapshot: 'Earbuds', pricePaiseSnapshot: 499900, quantity: 1 }],
    });
    await repo.updateOrderStatus(order.id, 'failed');
    const fetched = await repo.getOrderById(order.id);
    expect(fetched!.status).toBe('failed');
  });

  it('refuses mock-pay when order does not belong to user', async () => {
    const order = await repo.createOrder({
      userId: 'u1',
      totalPaise: 499900,
      providerOrderId: 'mock_123',
      items: [{ productId: 'p1', nameSnapshot: 'Earbuds', pricePaiseSnapshot: 499900, quantity: 1 }],
    });
    const fetched = await repo.getOrderById(order.id);
    expect(fetched!.user_id).toBe('u1');
    // A different user should not be able to pay
    expect(fetched!.user_id).not.toBe('u2');
  });

  it('refuses mock-pay when order is not in created state', async () => {
    const order = await repo.createOrder({
      userId: 'u1',
      totalPaise: 499900,
      providerOrderId: 'mock_123',
      items: [{ productId: 'p1', nameSnapshot: 'Earbuds', pricePaiseSnapshot: 499900, quantity: 1 }],
    });
    await repo.updateOrderStatus(order.id, 'paid');
    const fetched = await repo.getOrderById(order.id);
    expect(fetched!.status).not.toBe('created');
  });
});

describe('payment mode resolution', () => {
  it('uses mock mode when PAYMENT_MODE is mock', async () => {
    const { resolvePaymentMode } = await import('@/lib/payments/index');
    expect(resolvePaymentMode({ PAYMENT_MODE: 'mock' })).toBe('mock');
  });

  it('defaults to razorpay when PAYMENT_MODE is missing', async () => {
    const { resolvePaymentMode } = await import('@/lib/payments/index');
    expect(resolvePaymentMode({})).toBe('razorpay');
  });

  it('defaults to razorpay when PAYMENT_MODE is anything else', async () => {
    const { resolvePaymentMode } = await import('@/lib/payments/index');
    expect(resolvePaymentMode({ PAYMENT_MODE: 'something' })).toBe('razorpay');
  });
});

describe('mock payment provider', () => {
  it('creates an order with a mock_ prefix id', async () => {
    const { MockPaymentProvider } = await import('@/lib/payments/mock');
    const provider = new MockPaymentProvider();
    const result = await provider.createOrder(499900, 'receipt_123');
    expect(result.providerOrderId).toMatch(/^mock_/);
    expect(result.publicConfig.keyId).toBeUndefined();
  });
});

describe('razorpay provider', () => {
  it('throws payments_not_configured when keys are missing', async () => {
    const { RazorpayProvider, RazorpayNotConfiguredError } = await import('@/lib/payments/razorpay');
    const provider = new RazorpayProvider({});
    await expect(provider.createOrder(499900, 'r1')).rejects.toThrow(RazorpayNotConfiguredError);
    try {
      await provider.createOrder(100, 'r2');
    } catch (err) {
      expect((err as { code: string }).code).toBe('payments_not_configured');
    }
  });
});
