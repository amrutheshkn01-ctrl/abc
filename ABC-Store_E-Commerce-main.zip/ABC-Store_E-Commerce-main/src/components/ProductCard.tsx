import { CheckCircle2, XCircle, Plus } from 'lucide-react';
import type { Product } from '@/lib/types';
import { formatINR, classNames } from '@/lib/utils';
import { useCart } from '@/lib/cart/context';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const inStock = product.stock_status === 'in_stock';
  const { addItem } = useCart();

  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm transition-all hover:shadow-md">
      <div className="relative aspect-square overflow-hidden bg-gray-50">
        <img
          src={product.image_url}
          alt={product.name}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
        <div className="absolute top-3 right-3">
          <span
            className={classNames(
              'inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium',
              inStock ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700',
            )}
          >
            {inStock ? <CheckCircle2 className="h-3 w-3" /> : <XCircle className="h-3 w-3" />}
            {inStock ? 'In Stock' : 'Out of Stock'}
          </span>
        </div>
      </div>
      <div className="flex flex-1 flex-col p-4">
        <h3 className="text-sm font-semibold text-gray-900 line-clamp-2">{product.name}</h3>
        <p className="mt-1 text-xs text-gray-500 line-clamp-2 flex-1">{product.description}</p>
        <div className="mt-3 flex items-center justify-between">
          <p className="text-lg font-bold text-gray-900">{formatINR(product.price_paise)}</p>
          <button
            onClick={() => addItem(product.id)}
            disabled={!inStock}
            className={classNames(
              'flex items-center gap-1 rounded-lg px-3 py-2 text-xs font-medium transition-colors',
              inStock
                ? 'bg-blue-600 text-white hover:bg-blue-700'
                : 'cursor-not-allowed bg-gray-100 text-gray-400',
            )}
          >
            <Plus className="h-3.5 w-3.5" />
            Add to cart
          </button>
        </div>
      </div>
    </article>
  );
}
