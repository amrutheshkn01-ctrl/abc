import { forwardRef } from 'react';
import type { Product, StockStatus } from '@/lib/types';
import { Field } from '@/components/Field';
import { Button } from '@/components/Button';
import { X } from 'lucide-react';

interface ProductFormProps {
  initial?: Product | null;
  onSubmit: (data: Omit<Product, 'id' | 'created_at' | 'updated_at'> & { id?: string }) => void;
  onCancel: () => void;
  loading?: boolean;
}

interface FormState {
  name: string;
  description: string;
  price_paise: string;
  stock_status: StockStatus;
  image_url: string;
  active: boolean;
}

export const ProductForm = forwardRef<HTMLFormElement, ProductFormProps>(
  ({ initial, onSubmit, onCancel, loading }, ref) => {
    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const form = e.currentTarget;
      const formData = new FormData(form);
      const priceStr = formData.get('price_paise') as string;
      // Convert rupees to paise
      const rupees = parseFloat(priceStr);
      const price_paise = Math.round(rupees * 100);

      onSubmit({
        id: initial?.id,
        name: (formData.get('name') as string).trim(),
        description: (formData.get('description') as string).trim(),
        price_paise,
        stock_status: formData.get('stock_status') as StockStatus,
        image_url: (formData.get('image_url') as string).trim(),
        active: formData.get('active') === 'on',
      });
    };

    const state: FormState = {
      name: initial?.name ?? '',
      description: initial?.description ?? '',
      price_paise: initial ? String(initial.price_paise / 100) : '',
      stock_status: initial?.stock_status ?? 'in_stock',
      image_url: initial?.image_url ?? '',
      active: initial?.active ?? true,
    };

    return (
      <form ref={ref} onSubmit={handleSubmit} className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">
            {initial ? 'Edit Product' : 'Add Product'}
          </h3>
          <button type="button" onClick={onCancel} className="text-gray-400 hover:text-gray-600 transition-colors" aria-label="Close">
            <X className="h-5 w-5" />
          </button>
        </div>
        <Field label="Product Name" name="name" required placeholder="e.g. Wireless Earbuds Pro" defaultValue={state.name} />
        <Field label="Description" name="description" type="textarea" required placeholder="Product description" defaultValue={state.description} />
        <div className="grid grid-cols-2 gap-4">
          <Field label="Price (INR)" name="price_paise" type="number" required placeholder="e.g. 4999" defaultValue={state.price_paise} min={0} step={1} />
          <Field
            label="Stock Status"
            name="stock_status"
            type="select"
            required
            value={state.stock_status}
            options={[
              { value: 'in_stock', label: 'In Stock' },
              { value: 'out_of_stock', label: 'Out of Stock' },
            ]}
          />
        </div>
        <Field label="Image URL" name="image_url" type="url" required placeholder="https://..." defaultValue={state.image_url} />
        <Field label="Active (visible in catalog)" name="active" type="checkbox" value={state.active} placeholder="Show in public catalog" />
        <div className="flex justify-end gap-3 pt-2">
          <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
          <Button type="submit" loading={loading}>{initial ? 'Save Changes' : 'Add Product'}</Button>
        </div>
      </form>
    );
  },
);

ProductForm.displayName = 'ProductForm';
