import { ShoppingBag } from 'lucide-react';

export function Footer() {
  return (
    <footer className="mt-auto border-t border-gray-200 bg-white">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-between">
          <div className="flex items-center gap-2 text-gray-600">
            <ShoppingBag className="h-5 w-5 text-blue-600" />
            <span className="text-sm font-medium">Storefront</span>
          </div>
          <p className="text-xs text-gray-400">
            &copy; {new Date().getFullYear()} Storefront. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
