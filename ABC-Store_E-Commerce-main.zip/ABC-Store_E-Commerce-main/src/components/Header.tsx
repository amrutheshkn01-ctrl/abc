import { Link } from 'react-router-dom';
import { ShoppingBag, ShoppingCart } from 'lucide-react';
import { classNames } from '@/lib/utils';
import { useCart } from '@/lib/cart/context';
import type { User } from '@/lib/types';

interface HeaderProps {
  isAdmin?: boolean;
  user?: User | null;
}

export function Header({ isAdmin = false, user = null }: HeaderProps) {
  const { itemCount } = useCart();

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-gray-200">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center gap-2 text-gray-900">
            <ShoppingBag className="h-6 w-6 text-blue-600" />
            <span className="text-lg font-semibold tracking-tight">Storefront</span>
          </Link>
          <nav className="flex items-center gap-4">
            <Link to="/" className="text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors">
              Catalog
            </Link>
            {user && (
              <Link to="/my-orders" className="text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors">
                My orders
              </Link>
            )}
            <Link to="/cart" className="relative text-gray-700 hover:text-gray-900 transition-colors">
              <ShoppingCart className="h-5 w-5" />
              {itemCount > 0 && (
                <span className="absolute -top-2 -right-2 flex h-5 min-w-[20px] items-center justify-center rounded-full bg-blue-600 px-1 text-xs font-semibold text-white">
                  {itemCount > 99 ? '99+' : itemCount}
                </span>
              )}
            </Link>
            {user ? (
              <span className="text-sm font-medium text-gray-500">{user.email}</span>
            ) : (
              <Link to="/login" className="text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors">
                Sign in
              </Link>
            )}
            {isAdmin && (
              <span className={classNames('rounded-full bg-blue-50 px-3 py-1 text-xs font-medium text-blue-700')}>
                Admin
              </span>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
}
