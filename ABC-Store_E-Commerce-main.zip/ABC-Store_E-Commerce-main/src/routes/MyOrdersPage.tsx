import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Package } from 'lucide-react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { EmptyState, ErrorState } from '@/components/States';
import { Button } from '@/components/Button';
import { formatINR, formatDate, classNames } from '@/lib/utils';
import { apiFetch } from '@/lib/api';
import type { OrderWithItems, User, PaymentMethod } from '@/lib/types';

interface MyOrdersPageProps {
  user: User | null | undefined;
}

function statusLabel(order: OrderWithItems): { text: string; className: string } {
  if (order.payment_method === 'cod') {
    if (order.status === 'paid') return { text: 'Delivered - cash collected', className: 'bg-green-50 text-green-700' };
    return { text: 'Placed - pay on delivery', className: 'bg-amber-50 text-amber-700' };
  }
  if (order.status === 'paid') return { text: 'Paid', className: 'bg-green-50 text-green-700' };
  if (order.status === 'failed') return { text: 'Payment failed', className: 'bg-red-50 text-red-700' };
  return { text: 'Awaiting payment', className: 'bg-amber-50 text-amber-700' };
}

export function MyOrdersPage({ user }: MyOrdersPageProps) {
  const [orders, setOrders] = useState<OrderWithItems[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }
    setLoading(true);
    apiFetch('/api/orders/mine')
      .then((d) => setOrders((d as { orders: OrderWithItems[] }).orders ?? []))
      .catch(() => setError('Failed to load your orders. Please try again.'))
      .finally(() => setLoading(false));
  }, [user]);

  if (user === undefined) {
    return (
      <div className="flex min-h-screen flex-col bg-gray-50">
        <Header />
        <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-8 sm:px-6 lg:px-8">
          <div className="flex min-h-[200px] items-center justify-center">
            <svg className="h-8 w-8 animate-spin text-blue-600" viewBox="0 0 24 24" fill="none">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
            </svg>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (user === null) {
    return (
      <div className="flex min-h-screen flex-col bg-gray-50">
        <Header />
        <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-8 sm:px-6 lg:px-8">
          <div className="rounded-2xl border border-gray-200 bg-white p-8 text-center shadow-sm">
            <h1 className="mb-2 text-xl font-bold text-gray-900">Sign in to view your orders</h1>
            <p className="mb-6 text-sm text-gray-500">You need to be signed in to see your order history.</p>
            <Link to="/login?return=/my-orders" className="inline-flex items-center justify-center rounded-xl bg-blue-600 px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-blue-700">
              Go to sign in
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col bg-gray-50">
      <Header />
      <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-8 sm:px-6 lg:px-8">
        <h1 className="mb-6 text-2xl font-bold tracking-tight text-gray-900">My Orders</h1>

        {loading ? (
          <div className="flex min-h-[200px] items-center justify-center">
            <svg className="h-8 w-8 animate-spin text-blue-600" viewBox="0 0 24 24" fill="none">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
            </svg>
          </div>
        ) : error ? (
          <ErrorState message={error}>
            <Button onClick={() => window.location.reload()}>Try again</Button>
          </ErrorState>
        ) : orders.length === 0 ? (
          <EmptyState message="You have not placed any orders yet." />
        ) : (
          <div className="space-y-4">
            {orders.map((order) => {
              const badge = statusLabel(order);
              const methodLabel: Record<PaymentMethod, string> = { online: 'Online payment', cod: 'Cash on delivery' };
              return (
                <div key={order.id} className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <p className="text-xs text-gray-400">Order #{order.id.slice(0, 8)}</p>
                      <p className="text-xs text-gray-400">{formatDate(order.created_at)}</p>
                    </div>
                    <span className={classNames('inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium', badge.className)}>
                      {badge.text}
                    </span>
                  </div>
                  <div className="mt-3 space-y-1.5">
                    {order.items.map((item) => (
                      <div key={item.id} className="flex items-center justify-between text-sm">
                        <span className="text-gray-700">{item.name_snapshot} <span className="text-gray-400">× {item.quantity}</span></span>
                        <span className="text-gray-600">{formatINR(item.price_paise_snapshot * item.quantity)}</span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-3 border-t border-gray-100 pt-3 space-y-1">
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>{methodLabel[order.payment_method]}</span>
                      {order.cod_fee_paise > 0 && (
                        <span>COD handling charge: {formatINR(order.cod_fee_paise)}</span>
                      )}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">Total</span>
                      <span className="text-lg font-bold text-gray-900">{formatINR(order.total_paise)}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}

void Package;
