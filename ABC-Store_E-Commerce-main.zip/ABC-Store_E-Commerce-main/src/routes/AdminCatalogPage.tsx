import { useState } from 'react';
import type { Product, MutateRequest, ProductInput } from '@/lib/types';
import { AdminLayout } from '@/components/AdminLayout';
import { AdminProductRow } from '@/components/AdminProductRow';
import { ProductForm } from '@/components/ProductForm';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { Button } from '@/components/Button';
import { LoadingSpinner, ErrorState, EmptyState } from '@/components/States';
import { useToasts, ToastContainer } from '@/components/Toast';
import { Plus, Package } from 'lucide-react';
import type { User } from '@/lib/types';

interface AdminCatalogPageProps {
  currentUser: User;
  products: Product[];
  loading: boolean;
  error: string | null;
  onRefresh: () => void;
}

export function AdminCatalogPage({ currentUser, products, loading, error, onRefresh }: AdminCatalogPageProps) {
  const { toasts, addToast, dismissToast } = useToasts();
  const [showForm, setShowForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Product | null>(null);
  const [mutationLoading, setMutationLoading] = useState(false);

  const callMutate = async (request: MutateRequest) => {
    const res = await fetch('/api/admin/mutate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(request),
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({ error: 'Request failed' }));
      throw new Error(data.error || 'Mutation failed');
    }
    return res.json();
  };

  const handleSubmit = async (data: Omit<Product, 'id' | 'created_at' | 'updated_at'> & { id?: string }) => {
    setMutationLoading(true);
    try {
      const input: ProductInput = {
        id: data.id,
        name: data.name,
        description: data.description,
        price_paise: data.price_paise,
        stock_status: data.stock_status,
        image_url: data.image_url,
        active: data.active,
      };
      const action = data.id ? 'UPDATE' : 'ADD';
      await callMutate({ action, product: input });
      addToast(data.id ? 'Product updated successfully' : 'Product added successfully');
      setShowForm(false);
      setEditingProduct(null);
      onRefresh();
    } catch (err) {
      addToast(err instanceof Error ? err.message : 'An error occurred', 'error');
    } finally {
      setMutationLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setMutationLoading(true);
    try {
      await callMutate({ action: 'DELETE', productId: deleteTarget.id });
      addToast('Product deleted successfully');
      setDeleteTarget(null);
      onRefresh();
    } catch (err) {
      addToast(err instanceof Error ? err.message : 'An error occurred', 'error');
    } finally {
      setMutationLoading(false);
    }
  };

  if (loading) {
    return (
      <AdminLayout currentUser={currentUser}>
        <LoadingSpinner label="Loading products..." />
      </AdminLayout>
    );
  }

  if (error) {
    return (
      <AdminLayout currentUser={currentUser}>
        <ErrorState message={error}>
          <Button onClick={onRefresh}>Try again</Button>
        </ErrorState>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout currentUser={currentUser}>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Catalog Management</h1>
          <p className="mt-1 text-sm text-gray-500">{products.length} products total</p>
        </div>
        <Button onClick={() => { setEditingProduct(null); setShowForm(true); }}>
          <Plus className="h-4 w-4" />
          Add Product
        </Button>
      </div>

      {products.length === 0 && !showForm ? (
        <EmptyState message="No products yet. Click 'Add Product' to create your first one." />
      ) : (
        <div className="overflow-hidden rounded-xl border border-gray-200 bg-white">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="py-3 px-4 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">Product</th>
                  <th className="py-3 px-4 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">Price</th>
                  <th className="py-3 px-4 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">Stock</th>
                  <th className="py-3 px-4 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">Updated</th>
                  <th className="py-3 px-4 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">Actions</th>
                </tr>
              </thead>
              <tbody>
                {products.map((p) => (
                  <AdminProductRow
                    key={p.id}
                    product={p}
                    onEdit={(prod) => { setEditingProduct(prod); setShowForm(true); }}
                    onDelete={(prod) => setDeleteTarget(prod)}
                  />
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add/Edit modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => { setShowForm(false); setEditingProduct(null); }} />
          <div className="relative w-full max-w-lg rounded-2xl bg-white p-6 shadow-xl max-h-[90vh] overflow-y-auto">
            <ProductForm
              initial={editingProduct}
              onSubmit={handleSubmit}
              onCancel={() => { setShowForm(false); setEditingProduct(null); }}
              loading={mutationLoading}
            />
          </div>
        </div>
      )}

      {/* Delete confirmation */}
      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete Product"
        message={`Are you sure you want to delete "${deleteTarget?.name}"? This action cannot be undone.`}
        confirmLabel="Delete"
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </AdminLayout>
  );
}
