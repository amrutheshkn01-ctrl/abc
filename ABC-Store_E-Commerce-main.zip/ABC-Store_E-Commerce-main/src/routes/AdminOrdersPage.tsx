import { useState, useEffect, useCallback } from 'react';
import { Package } from 'lucide-react';
import { AdminLayout } from '@/components/AdminLayout';
import { Button } from '@/components/Button';
import { ErrorState, EmptyState } from '@/components/States';
import { formatINR, formatDate, classNames } from '@/lib/utils';
import { apiFetch, apiPost } from '@/lib/api';
import type { OrderWithItems, User, PaymentMethod } from '@/lib/types';

interface AdminOrdersPageProps {
  currentUser: User;
}

function statusBadge(order: OrderWithItems): { text: string; className: string } {
  if (order.payment_method === 'cod') {
    if (order.status === 'paid') return { text: 'Delivered', className: 'bg-green-50 text-green-700' };
    return { text: 'Awaiting delivery', className: 'bg-amber-50 text-amber-700' };
  }
  if (order.status === 'paid') return { text: 'Paid', className: 'bg-green-50 text-green-700' };
  if (order.status === 'failed') return { text: 'Failed', className: 'bg-red-50 text-red-700' };
  return { text: 'Awaiting payment', className: 'bg-amber-50 text-amber-700' };
}

export function AdminOrdersPage({ currentUser }: AdminOrdersPageProps) {
  const [orders, setOrders] = useState<OrderWithItems[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actioningId, setActioningId] = useState<string | null>(null);

  const loadOrders = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiFetch('/api/admin/orders') as { orders: OrderWithItems[] };
      setOrders(data.orders ?? []);
    } catch {
      setError('Failed to load orders. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadOrders();
  }, [loadOrders]);

  const handleMarkDelivered = async (orderId: string) => {
    setActioningId(orderId);
    try {
      await apiPost('/api/admin/order-status', { orderId, action: 'mark_delivered' });
      await loadOrders();
    } catch {
      setError('Failed to update order status.');
    } finally {
      setActioningId(null);
    }
  };

  return (
    <AdminLayout currentUser={currentUser}>
      <div className="mb-6 flex items-center gap-2">
        <Package className="h-5 w-5 text-gray-700" />
        <h1 className="text-xl font-bold tracking-tight text-gray-900">Orders</h1>
      </div>

      {loading ? (
        <div className="flex min-h-[200px] items-center justify-center">
          <svg className="h-8 w-8 animate-spin text-blue-600" viewBox="0 0 24 24" fill="none">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
          </svg>
        </div>
      ) : error ? (
        <ErrorState message={error}>
          <Button onClick={loadOrders}>Try again</Button>
        </ErrorState>
      ) : orders.length === 0 ? (
        <EmptyState message="No orders yet." />
      ) : (
        <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-gray-100 bg-gray-50 text-xs uppercase tracking-wide text-gray-500">
                <tr>
                  <th className="py-3 px-4">Order</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Payment</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Total</th>
                  <th className="py-3 px-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => {
                  const badge = statusBadge(order);
                  const methodLabel: Record<PaymentMethod, string> = { online: 'Online', cod: 'COD' };
                  return (
                    <tr key={order.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                      <td className="py-3 px-4">
                        <p className="font-medium text-gray-900">#{order.id.slice(0, 8)}</p>
                        <p className="text-xs text-gray-400">{formatDate(order.created_at)}</p>
                      </td>
                      <td className="py-3 px-4">
                        <p className="text-gray-700">{order.shipping_name ?? '—'}</p>
                        <p className="text-xs text-gray-400">{order.shipping_phone ?? ''}</p>
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-gray-700">{methodLabel[order.payment_method]}</span>
                        {order.cod_fee_paise > 0 && (
                          <p className="text-xs text-gray-400">+{formatINR(order.cod_fee_paise)} fee</p>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <span className={classNames('inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium', badge.className)}>
                          {badge.text}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-medium text-gray-900">{formatINR(order.total_paise)}</td>
                      <td className="py-3 px-4">
                        {order.payment_method === 'cod' && order.status !== 'paid' && (
                          <Button
                            variant="secondary"
                            onClick={() => handleMarkDelivered(order.id)}
                            loading={actioningId === order.id}
                            className="px-3 py-1.5 text-xs"
                          >
                            Mark delivered
                          </Button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
