import type { Repository } from './db/repository';
import type { User, MutateRequest, MutateResult, ProductInput, Product } from './types';
import { mutateRequestSchema } from './validation';
import { isApprovedAdmin } from './auth/session';

export interface MutateContext {
  repo: Repository;
  user: User | null;
}

export async function handleMutate(ctx: MutateContext, body: unknown): Promise<MutateResult> {
  const { repo, user } = ctx;

  // Step 1: Authenticate — must be approved admin/superadmin
  if (!isApprovedAdmin(user)) {
    return { success: false, error: 'Forbidden: admin access required' };
  }

  // Step 2: Validate payload with Zod
  const parsed = mutateRequestSchema.safeParse(body);
  if (!parsed.success) {
    return { success: false, error: parsed.error.issues.map((i) => i.message).join('; ') };
  }

  const request = parsed.data as MutateRequest;

  try {
    // Step 3: Apply D1 change
    let product: Product | undefined;

    if (request.action === 'ADD' && request.product) {
      product = await repo.addProduct(request.product as ProductInput);
    } else if (request.action === 'UPDATE' && request.product) {
      const existing = await repo.getProductById(request.product.id!);
      if (!existing) {
        return { success: false, error: 'Product not found' };
      }
      product = await repo.updateProduct(request.product as ProductInput);
    } else if (request.action === 'DELETE' && request.productId) {
      const existing = await repo.getProductById(request.productId);
      if (!existing) {
        return { success: false, error: 'Product not found' };
      }
      await repo.deleteProduct(request.productId);
    } else {
      return { success: false, error: 'Invalid action or missing data' };
    }

    // Step 4: Rebuild KV cache with retry
    const kvSuccess = await repo.rebuildKVCacheWithRetry();
    if (!kvSuccess) {
      console.error('KV cache rebuild failed after retry, but D1 write succeeded');
    }

    return { success: true, product };
  } catch (err) {
    console.error('Mutation error:', err);
    return { success: false, error: err instanceof Error ? err.message : 'Internal error' };
  }
}
