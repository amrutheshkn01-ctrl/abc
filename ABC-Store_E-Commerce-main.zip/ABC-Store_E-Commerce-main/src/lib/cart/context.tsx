import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { Product, CartItem } from '../types';

const STORAGE_KEY = 'storefront_cart';
const MIN_QTY = 1;
const MAX_QTY = 10;

interface CartContextValue {
  items: CartItem[];
  addItem: (productId: string, quantity?: number) => void;
  removeItem: (productId: string) => void;
  setQuantity: (productId: string, quantity: number) => void;
  clear: () => void;
  itemCount: number;
}

const CartContext = createContext<CartContextValue | null>(null);

function readStorage(): CartItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as CartItem[];
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (item) => typeof item?.productId === 'string' && typeof item?.quantity === 'number',
    );
  } catch {
    return [];
  }
}

function writeStorage(items: CartItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch {
    // ignore write errors
  }
}

function clampQty(qty: number): number {
  return Math.max(MIN_QTY, Math.min(MAX_QTY, Math.floor(qty)));
}

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);

  useEffect(() => {
    setItems(readStorage());
  }, []);

  const persist = useCallback((next: CartItem[]) => {
    setItems(next);
    writeStorage(next);
  }, []);

  const addItem = useCallback(
    (productId: string, quantity = 1) => {
      setItems((prev) => {
        const existing = prev.find((i) => i.productId === productId);
        let next: CartItem[];
        if (existing) {
          next = prev.map((i) =>
            i.productId === productId ? { ...i, quantity: clampQty(i.quantity + quantity) } : i,
          );
        } else {
          next = [...prev, { productId, quantity: clampQty(quantity) }];
        }
        writeStorage(next);
        return next;
      });
    },
    [],
  );

  const removeItem = useCallback((productId: string) => {
    setItems((prev) => {
      const next = prev.filter((i) => i.productId !== productId);
      writeStorage(next);
      return next;
    });
  }, []);

  const setQuantity = useCallback((productId: string, quantity: number) => {
    setItems((prev) => {
      const next = prev.map((i) =>
        i.productId === productId ? { ...i, quantity: clampQty(quantity) } : i,
      );
      writeStorage(next);
      return next;
    });
  }, []);

  const clear = useCallback(() => {
    persist([]);
  }, [persist]);

  const itemCount = items.reduce((sum, i) => sum + i.quantity, 0);

  return (
    <CartContext.Provider value={{ items, addItem, removeItem, setQuantity, clear, itemCount }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}

export function useCartWithCatalog(products: Product[]) {
  const { items, ...rest } = useCart();

  const productMap = new Map(products.map((p) => [p.id, p]));
  const validItems = items.filter((i) => productMap.has(i.productId));
  const enriched = validItems.map((i) => {
    const product = productMap.get(i.productId)!;
    return { ...i, product, outOfStock: product.stock_status === 'out_of_stock' };
  });

  const subtotalPaise = enriched.reduce(
    (sum, i) => sum + i.product.price_paise * i.quantity,
    0,
  );

  return { ...rest, items: validItems, enriched, subtotalPaise };
}
