import { z } from 'zod';

export const productInputSchema = z.object({
  id: z.string().optional(),
  name: z.string().min(1, 'Name is required').max(200),
  description: z.string().min(1, 'Description is required').max(5000),
  price_paise: z.number().int('Price must be an integer').positive('Price must be positive'),
  stock_status: z.enum(['in_stock', 'out_of_stock']),
  image_url: z.string().url('Must be a valid URL').max(2048),
  active: z.boolean(),
});

export const mutateRequestSchema = z.object({
  action: z.enum(['ADD', 'UPDATE', 'DELETE']),
  product: productInputSchema.optional(),
  productId: z.string().optional(),
}).superRefine((data, ctx) => {
  if ((data.action === 'ADD' || data.action === 'UPDATE') && !data.product) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'Product is required for ADD and UPDATE actions',
      path: ['product'],
    });
  }
  if (data.action === 'UPDATE' && data.product && !data.product.id) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'Product id is required for UPDATE action',
      path: ['product', 'id'],
    });
  }
  if (data.action === 'DELETE' && !data.productId) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'productId is required for DELETE action',
      path: ['productId'],
    });
  }
});

export const adminActionSchema = z.enum(['approve_admin', 'revoke_admin', 'delete_admin_user', 'request_admin']);

export const adminActionRequestSchema = z.object({
  action: adminActionSchema,
  targetUserId: z.string().optional(),
}).superRefine((data, ctx) => {
  if (data.action !== 'request_admin' && !data.targetUserId) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'targetUserId is required for this action',
      path: ['targetUserId'],
    });
  }
});

export const orderItemInputSchema = z.object({
  productId: z.string().min(1),
  nameSnapshot: z.string().min(1, 'Name snapshot is required'),
  pricePaiseSnapshot: z.number().int().positive('Price must be positive'),
  quantity: z.number().int().positive('Quantity must be positive').max(10, 'Max 10 per item'),
});

export const orderInputSchema = z.object({
  userId: z.string().min(1, 'User ID is required'),
  totalPaise: z.number().int().positive('Total must be positive'),
  shippingName: z.string().max(200).optional(),
  shippingPhone: z.string().max(20).optional(),
  shippingAltPhone: z.string().max(20).optional(),
  shippingAddress: z.string().max(2000).optional(),
  items: z.array(orderItemInputSchema).min(1, 'At least one item is required'),
});

export const indianMobileSchema = z
  .string()
  .min(1, 'Phone is required')
  .transform((v) => v.replace(/\s+/g, ''))
  .refine((v) => {
    let s = v;
    if (s.startsWith('+91')) s = s.slice(3);
    else if (s.startsWith('0')) s = s.slice(1);
    return /^[6-9]\d{9}$/.test(s);
  }, 'Enter a valid 10-digit Indian mobile number (starts with 6-9)');

export const pincodeSchema = z
  .string()
  .min(1, 'Pincode is required')
  .transform((v) => v.replace(/\s+/g, ''))
  .refine((v) => /^\d{6}$/.test(v), 'Pincode must be exactly 6 digits');

export const checkoutRequestSchema = z.object({
  items: z.array(z.object({
    productId: z.string().min(1, 'Product ID is required'),
    quantity: z.number().int().min(1, 'Min 1 per item').max(10, 'Max 10 per item'),
  })).min(1, 'Cart is empty'),
  shipping: z.object({
    name: z.string().min(1, 'Name is required').max(200),
    phone: indianMobileSchema,
    altPhone: z.string().max(20).optional(),
    address: z.string().min(1, 'Address is required').max(2000),
  }),
  paymentMethod: z.enum(['online', 'cod']).optional(),
});

export const cancelOrderSchema = z.object({
  orderId: z.string().min(1, 'Order ID is required'),
  reason: z.string().max(500).optional(),
});

export const updateShippingSchema = z.object({
  orderId: z.string().min(1, 'Order ID is required'),
  name: z.string().min(1, 'Name is required').max(200),
  phone: indianMobileSchema,
  altPhone: z.string().max(20).optional(),
  address: z.string().min(1, 'Address is required').max(2000),
});

export const addressInputSchema = z.object({
  label: z.string().min(1, 'Label is required').max(50),
  name: z.string().min(1, 'Name is required').max(200),
  phone: indianMobileSchema,
  altPhone: z.string().max(20).optional(),
  address_line: z.string().min(1, 'Address is required').max(2000),
  city: z.string().min(1, 'City is required').max(100),
  state: z.string().min(1, 'State is required').max(100),
  pincode: pincodeSchema,
  is_default: z.boolean().optional(),
});

export const profileInputSchema = z.object({
  display_name: z.string().max(200).optional(),
  phone: indianMobileSchema.optional(),
  alt_phone: z.string().max(20).optional(),
});
