import type { User, Product, CatalogData, ProductInput, ApprovalStatus, Role, Order, OrderItem, OrderWithItems, OrderInput, Address, AddressInput, ProfileInput } from '../types';
import type { Repository, SessionRecord } from './repository';
import { generateId } from '../utils';

interface D1Result {
  results?: Record<string, unknown>[];
  meta?: { changes?: number };
}

interface D1Database {
  prepare(sql: string): { bind(...values: unknown[]): { all(): Promise<D1Result>; run(): Promise<D1Result>; first<T>(): Promise<T | null> } };
}

interface KVNamespace {
  get(key: string): Promise<string | null>;
  put(key: string, value: string): Promise<void>;
}

const KV_KEY = 'LIVE_STOREFRONT_DATA';

export class D1KVRepository implements Repository {
  constructor(
    private db: D1Database,
    private kv: KVNamespace,
  ) {}

  async getCatalog(): Promise<CatalogData> {
    try {
      const raw = await this.kv.get(KV_KEY);
      if (raw) {
        const products = JSON.parse(raw) as Product[];
        return { products, source: 'kv' };
      }
    } catch {
      // fall through to D1
    }
    const result = await this.db
      .prepare('SELECT * FROM products WHERE active = 1 ORDER BY created_at DESC')
      .bind()
      .all();
    const products = (result.results ?? []) as unknown as Product[];
    return { products, source: 'd1' };
  }

  async getProductById(id: string): Promise<Product | null> {
    return this.db
      .prepare('SELECT * FROM products WHERE id = ?')
      .bind(id)
      .first<Product>();
  }

  async getAllProducts(): Promise<Product[]> {
    const result = await this.db
      .prepare('SELECT * FROM products ORDER BY created_at DESC')
      .bind()
      .all();
    return (result.results ?? []) as unknown as Product[];
  }

  async addProduct(input: ProductInput): Promise<Product> {
    const id = generateId();
    const now = new Date().toISOString();
    await this.db
      .prepare('INSERT INTO products (id, name, description, price_paise, stock_status, image_url, active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
      .bind(id, input.name, input.description, input.price_paise, input.stock_status, input.image_url, input.active ? 1 : 0, now, now)
      .run();
    return { ...input, id, created_at: now, updated_at: now };
  }

  async updateProduct(input: ProductInput): Promise<Product> {
    const now = new Date().toISOString();
    await this.db
      .prepare('UPDATE products SET name = ?, description = ?, price_paise = ?, stock_status = ?, image_url = ?, active = ?, updated_at = ? WHERE id = ?')
      .bind(input.name, input.description, input.price_paise, input.stock_status, input.image_url, input.active ? 1 : 0, now, input.id)
      .run();
    const updated = await this.getProductById(input.id!);
    if (!updated) throw new Error('Product not found after update');
    return { ...updated, updated_at: now };
  }

  async deleteProduct(id: string): Promise<void> {
    await this.db.prepare('DELETE FROM products WHERE id = ?').bind(id).run();
  }

  async getUserById(id: string): Promise<User | null> {
    return this.db.prepare('SELECT * FROM users WHERE id = ?').bind(id).first<User>();
  }

  async getUserByEmail(email: string): Promise<User | null> {
    return this.db.prepare('SELECT * FROM users WHERE email = ?').bind(email).first<User>();
  }

  async getAllUsers(): Promise<User[]> {
    const result = await this.db.prepare('SELECT * FROM users ORDER BY created_at DESC').bind().all();
    return (result.results ?? []) as unknown as User[];
  }

  async getPendingAdminRequests(): Promise<User[]> {
    const result = await this.db
      .prepare("SELECT * FROM users WHERE approval_status = 'pending' AND role != 'buyer' ORDER BY created_at DESC")
      .bind()
      .all();
    return (result.results ?? []) as unknown as User[];
  }

  async createUser(email: string): Promise<User> {
    const id = generateId();
    const now = new Date().toISOString();
    await this.db
      .prepare('INSERT INTO users (id, email, role, approval_status, created_at) VALUES (?, ?, ?, ?, ?)')
      .bind(id, email, 'buyer', 'approved', now)
      .run();
    return { id, email, role: 'buyer', approval_status: 'approved', created_at: now, display_name: null, phone: null, alt_phone: null };
  }

  async updateUserRole(id: string, role: Role): Promise<void> {
    await this.db.prepare('UPDATE users SET role = ? WHERE id = ?').bind(role, id).run();
  }

  async updateUserApproval(id: string, status: ApprovalStatus): Promise<void> {
    await this.db.prepare('UPDATE users SET approval_status = ? WHERE id = ?').bind(status, id).run();
  }

  async deleteUser(id: string): Promise<void> {
    await this.db.prepare('DELETE FROM users WHERE id = ?').bind(id).run();
  }

  async getSuperadminCount(): Promise<number> {
    const row = await this.db.prepare("SELECT COUNT(*) as count FROM users WHERE role = 'superadmin'").bind().first<{ count: number }>();
    return row?.count ?? 0;
  }

  async getProfile(userId: string): Promise<User | null> {
    return this.db.prepare('SELECT id, email, role, approval_status, created_at, display_name, phone, alt_phone FROM users WHERE id = ?').bind(userId).first<User>();
  }

  async updateProfile(userId: string, input: ProfileInput): Promise<void> {
    await this.db
      .prepare('UPDATE users SET display_name = ?, phone = ?, alt_phone = ? WHERE id = ?')
      .bind(input.display_name ?? null, input.phone ?? null, input.alt_phone ?? null, userId)
      .run();
  }

  async createSession(sessionHash: string, userId: string, expiresAt: string): Promise<SessionRecord> {
    const id = generateId();
    await this.db.prepare('INSERT INTO sessions (id, user_id, expires_at) VALUES (?, ?, ?)').bind(sessionHash, userId, expiresAt).run();
    return { id: sessionHash, user_id: userId, expires_at: expiresAt };
  }

  async getSessionByHash(sessionHash: string): Promise<SessionRecord | null> {
    const session = await this.db.prepare('SELECT * FROM sessions WHERE id = ?').bind(sessionHash).first<SessionRecord>();
    if (!session) return null;
    if (new Date(session.expires_at) < new Date()) {
      await this.deleteSessionByHash(sessionHash);
      return null;
    }
    return session;
  }

  async deleteSessionByHash(sessionHash: string): Promise<void> {
    await this.db.prepare('DELETE FROM sessions WHERE id = ?').bind(sessionHash).run();
  }

  async rebuildKVCache(): Promise<void> {
    const result = await this.db
      .prepare('SELECT * FROM products WHERE active = 1 ORDER BY created_at DESC')
      .bind()
      .all();
    const products = (result.results ?? []) as unknown as Product[];
    await this.kv.put(KV_KEY, JSON.stringify(products));
  }

  async rebuildKVCacheWithRetry(): Promise<boolean> {
    try {
      await this.rebuildKVCache();
      return true;
    } catch (err) {
      console.error('KV write failed, retrying once:', err);
      try {
        await this.rebuildKVCache();
        return true;
      } catch (err2) {
        console.error('KV write retry also failed:', err2);
        return false;
      }
    }
  }

  async createOrder(input: OrderInput): Promise<OrderWithItems> {
    const id = generateId();
    const now = new Date().toISOString();
    const paymentMethod = input.paymentMethod ?? 'online';
    const codFeePaise = input.codFeePaise ?? 0;
    await this.db
      .prepare('INSERT INTO orders (id, user_id, status, total_paise, payment_method, cod_fee_paise, razorpay_order_id, shipping_name, shipping_phone, shipping_alt_phone, shipping_address, fulfilment_status, cancelled_at, cancel_reason, payment_collected_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
      .bind(id, input.userId, 'created', input.totalPaise, paymentMethod, codFeePaise, input.providerOrderId ?? null, input.shippingName ?? null, input.shippingPhone ?? null, input.shippingAltPhone ?? null, input.shippingAddress ?? null, 'pending', null, null, null, now, now)
      .run();
    const items: OrderItem[] = [];
    for (const item of input.items) {
      const itemId = generateId();
      await this.db
        .prepare('INSERT INTO order_items (id, order_id, product_id, name_snapshot, price_paise_snapshot, quantity) VALUES (?, ?, ?, ?, ?, ?)')
        .bind(itemId, id, item.productId, item.nameSnapshot, item.pricePaiseSnapshot, item.quantity)
        .run();
      items.push({ id: itemId, order_id: id, product_id: item.productId, name_snapshot: item.nameSnapshot, price_paise_snapshot: item.pricePaiseSnapshot, quantity: item.quantity });
    }
    const order: Order = { id, user_id: input.userId, status: 'created', total_paise: input.totalPaise, payment_method: paymentMethod, cod_fee_paise: codFeePaise, razorpay_order_id: null, razorpay_payment_id: null, shipping_name: input.shippingName ?? null, shipping_phone: input.shippingPhone ?? null, shipping_alt_phone: input.shippingAltPhone ?? null, shipping_address: input.shippingAddress ?? null, fulfilment_status: 'pending', cancelled_at: null, cancel_reason: null, payment_collected_at: null, created_at: now, updated_at: now };
    return { ...order, items };
  }

  async getOrderById(id: string): Promise<OrderWithItems | null> {
    const order = await this.db.prepare('SELECT * FROM orders WHERE id = ?').bind(id).first<Order>();
    if (!order) return null;
    const itemsResult = await this.db.prepare('SELECT * FROM order_items WHERE order_id = ?').bind(id).all();
    const items = (itemsResult.results ?? []) as unknown as OrderItem[];
    return { ...order, items };
  }

  async getOrderForUser(orderId: string, userId: string): Promise<OrderWithItems | null> {
    const order = await this.db.prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?').bind(orderId, userId).first<Order>();
    if (!order) return null;
    const itemsResult = await this.db.prepare('SELECT * FROM order_items WHERE order_id = ?').bind(orderId).all();
    const items = (itemsResult.results ?? []) as unknown as OrderItem[];
    return { ...order, items };
  }

  async getOrdersByUser(userId: string): Promise<Order[]> {
    const result = await this.db.prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC').bind(userId).all();
    return (result.results ?? []) as unknown as Order[];
  }

  async getOrdersByUserWithItems(userId: string): Promise<OrderWithItems[]> {
    const result = await this.db.prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC').bind(userId).all();
    const orders = (result.results ?? []) as unknown as Order[];
    const withItems: OrderWithItems[] = [];
    for (const order of orders) {
      const itemsResult = await this.db.prepare('SELECT * FROM order_items WHERE order_id = ?').bind(order.id).all();
      const items = (itemsResult.results ?? []) as unknown as OrderItem[];
      withItems.push({ ...order, items });
    }
    return withItems;
  }

  async getAllOrders(): Promise<Order[]> {
    const result = await this.db.prepare('SELECT * FROM orders ORDER BY created_at DESC').bind().all();
    return (result.results ?? []) as unknown as Order[];
  }

  async getAllOrdersWithItems(): Promise<OrderWithItems[]> {
    const result = await this.db.prepare('SELECT * FROM orders ORDER BY created_at DESC').bind().all();
    const orders = (result.results ?? []) as unknown as Order[];
    const withItems: OrderWithItems[] = [];
    for (const order of orders) {
      const itemsResult = await this.db.prepare('SELECT * FROM order_items WHERE order_id = ?').bind(order.id).all();
      const items = (itemsResult.results ?? []) as unknown as OrderItem[];
      withItems.push({ ...order, items });
    }
    return withItems;
  }

  async updateOrderStatus(id: string, status: Order['status']): Promise<void> {
    const now = new Date().toISOString();
    await this.db.prepare('UPDATE orders SET status = ?, updated_at = ? WHERE id = ?').bind(status, now, id).run();
  }

  async markOrderPaymentCollected(id: string): Promise<void> {
    const now = new Date().toISOString();
    await this.db.prepare("UPDATE orders SET status = 'paid', payment_collected_at = ?, updated_at = ? WHERE id = ?").bind(now, now, id).run();
  }

  async cancelOrder(orderId: string, userId: string, reason: string | null): Promise<void> {
    const now = new Date().toISOString();
    await this.db
      .prepare("UPDATE orders SET status = 'cancelled', cancelled_at = ?, cancel_reason = ?, updated_at = ? WHERE id = ? AND user_id = ?")
      .bind(now, reason, now, orderId, userId)
      .run();
  }

  async updateOrderShipping(orderId: string, userId: string, name: string, phone: string, altPhone: string | null, address: string): Promise<void> {
    const now = new Date().toISOString();
    await this.db
      .prepare('UPDATE orders SET shipping_name = ?, shipping_phone = ?, shipping_alt_phone = ?, shipping_address = ?, updated_at = ? WHERE id = ? AND user_id = ?')
      .bind(name, phone, altPhone, address, now, orderId, userId)
      .run();
  }

  async setFulfilmentStatus(orderId: string, status: 'pending' | 'shipped' | 'delivered'): Promise<void> {
    const now = new Date().toISOString();
    await this.db.prepare('UPDATE orders SET fulfilment_status = ?, updated_at = ? WHERE id = ?').bind(status, now, orderId).run();
  }

  async listAddresses(userId: string): Promise<Address[]> {
    const result = await this.db.prepare('SELECT * FROM addresses WHERE user_id = ? ORDER BY is_default DESC, created_at DESC').bind(userId).all();
    return (result.results ?? []) as unknown as Address[];
  }

  async createAddress(userId: string, input: AddressInput): Promise<Address> {
    const count = await this.getAddressCount(userId);
    if (count >= 5) throw new Error('Maximum of 5 addresses allowed');
    const id = generateId();
    const now = new Date().toISOString();
    const isDefault = input.is_default ?? false;
    if (isDefault) {
      await this.db.prepare('UPDATE addresses SET is_default = 0 WHERE user_id = ?').bind(userId).run();
    }
    await this.db
      .prepare('INSERT INTO addresses (id, user_id, label, name, phone, alt_phone, address_line, city, state, pincode, is_default, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
      .bind(id, userId, input.label, input.name, input.phone, input.alt_phone ?? null, input.address_line, input.city, input.state, input.pincode, isDefault ? 1 : 0, now)
      .run();
    return { id, user_id: userId, label: input.label, name: input.name, phone: input.phone, alt_phone: input.alt_phone ?? null, address_line: input.address_line, city: input.city, state: input.state, pincode: input.pincode, is_default: isDefault, created_at: now };
  }

  async updateAddress(addressId: string, userId: string, input: AddressInput): Promise<Address> {
    const existing = await this.db.prepare('SELECT * FROM addresses WHERE id = ? AND user_id = ?').bind(addressId, userId).first<Address>();
    if (!existing) throw new Error('Address not found');
    if (input.is_default) {
      await this.db.prepare('UPDATE addresses SET is_default = 0 WHERE user_id = ?').bind(userId).run();
    }
    await this.db
      .prepare('UPDATE addresses SET label = ?, name = ?, phone = ?, alt_phone = ?, address_line = ?, city = ?, state = ?, pincode = ?, is_default = ? WHERE id = ? AND user_id = ?')
      .bind(input.label, input.name, input.phone, input.alt_phone ?? null, input.address_line, input.city, input.state, input.pincode, input.is_default ?? existing.is_default ? 1 : 0, addressId, userId)
      .run();
    const updated = await this.db.prepare('SELECT * FROM addresses WHERE id = ?').bind(addressId).first<Address>();
    if (!updated) throw new Error('Address not found after update');
    return updated;
  }

  async deleteAddress(addressId: string, userId: string): Promise<void> {
    await this.db.prepare('DELETE FROM addresses WHERE id = ? AND user_id = ?').bind(addressId, userId).run();
  }

  async setDefaultAddress(addressId: string, userId: string): Promise<void> {
    const existing = await this.db.prepare('SELECT * FROM addresses WHERE id = ? AND user_id = ?').bind(addressId, userId).first<Address>();
    if (!existing) throw new Error('Address not found');
    await this.db.prepare('UPDATE addresses SET is_default = 0 WHERE user_id = ?').bind(userId).run();
    await this.db.prepare('UPDATE addresses SET is_default = 1 WHERE id = ? AND user_id = ?').bind(addressId, userId).run();
  }

  async getAddressCount(userId: string): Promise<number> {
    const row = await this.db.prepare('SELECT COUNT(*) as count FROM addresses WHERE user_id = ?').bind(userId).first<{ count: number }>();
    return row?.count ?? 0;
  }
}
