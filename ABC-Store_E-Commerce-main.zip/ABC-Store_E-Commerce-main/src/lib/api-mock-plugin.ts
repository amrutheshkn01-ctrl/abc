import type { Plugin } from 'vite';
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { User } from '@/lib/types';

// Lazy-loaded modules — these use the @/ alias which is only available
// once Vite's module resolution is active (i.e. during dev server request handling,
// not during config loading).
let loaded: {
  getRepository: typeof import('@/lib/db')['getRepository'];
  handleMutate: typeof import('@/lib/mutate-handler')['handleMutate'];
  handleAdminAction: typeof import('@/lib/admin-action-handler')['handleAdminAction'];
  getUserFromRequest: typeof import('@/lib/auth/session')['getUserFromRequest'];
  isApprovedAdmin: typeof import('@/lib/auth/session')['isApprovedAdmin'];
  findOrCreateUser: typeof import('@/lib/auth/session')['findOrCreateUser'];
  verifyGoogleToken: typeof import('@/lib/auth/google-token')['verifyGoogleToken'];
  generateSessionId: typeof import('@/lib/auth/cookie')['generateSessionId'];
  hashSessionId: typeof import('@/lib/auth/cookie')['hashSessionId'];
  getSessionExpiry: typeof import('@/lib/auth/cookie')['getSessionExpiry'];
  buildSessionCookieHeader: typeof import('@/lib/auth/cookie')['buildSessionCookieHeader'];
  buildDeleteCookieHeader: typeof import('@/lib/auth/cookie')['buildDeleteCookieHeader'];
  parseCookies: typeof import('@/lib/auth/cookie')['parseCookies'];
  getSessionCookieName: typeof import('@/lib/auth/cookie')['getSessionCookieName'];
  getPaymentProvider: typeof import('@/lib/payments/index')['getPaymentProvider'];
  resolvePaymentMode: typeof import('@/lib/payments/index')['resolvePaymentMode'];
} | null = null;

async function loadModules() {
  if (loaded) return loaded;
  const db = await import('@/lib/db');
  const mutate = await import('@/lib/mutate-handler');
  const adminAction = await import('@/lib/admin-action-handler');
  const session = await import('@/lib/auth/session');
  const googleToken = await import('@/lib/auth/google-token');
  const cookie = await import('@/lib/auth/cookie');
  const payments = await import('@/lib/payments/index');
  loaded = {
    getRepository: db.getRepository,
    handleMutate: mutate.handleMutate,
    handleAdminAction: adminAction.handleAdminAction,
    getUserFromRequest: session.getUserFromRequest,
    isApprovedAdmin: session.isApprovedAdmin,
    findOrCreateUser: session.findOrCreateUser,
    verifyGoogleToken: googleToken.verifyGoogleToken,
    generateSessionId: cookie.generateSessionId,
    hashSessionId: cookie.hashSessionId,
    getSessionExpiry: cookie.getSessionExpiry,
    buildSessionCookieHeader: cookie.buildSessionCookieHeader,
    buildDeleteCookieHeader: cookie.buildDeleteCookieHeader,
    parseCookies: cookie.parseCookies,
    getSessionCookieName: cookie.getSessionCookieName,
    getPaymentProvider: payments.getPaymentProvider,
    resolvePaymentMode: payments.resolvePaymentMode,
  };
  return loaded;
}

async function handleApiRoute(req: IncomingMessage, res: ServerResponse): Promise<boolean> {
  const url = req.url ?? '';
  const method = req.method ?? 'GET';

  if (!url.startsWith('/api/')) return false;

  const m = await loadModules();
  const cookieHeader = req.headers.cookie ?? null;
  const repo = m.getRepository();
  const user = await m.getUserFromRequest(repo, cookieHeader);

  const sendJson = (status: number, body: unknown, headers: Record<string, string> = {}) => {
    res.writeHead(status, { 'Content-Type': 'application/json', ...headers });
    res.end(JSON.stringify(body));
  };

  const readBody = (): Promise<string> => {
    return new Promise((resolve) => {
      let data = '';
      req.on('data', (chunk) => { data += chunk; });
      req.on('end', () => resolve(data));
    });
  };

  // GET /api/catalog — returns plain product array (matches real Cloudflare function)
  if (url === '/api/catalog' && method === 'GET') {
    const data = await repo.getCatalog();
    sendJson(200, data.products ?? []);
    return true;
  }

  // GET /api/auth/me
  if (url === '/api/auth/me' && method === 'GET') {
    sendJson(200, { user });
    return true;
  }

  // POST /api/auth/google
  if (url === '/api/auth/google' && method === 'POST') {
    const body = JSON.parse(await readBody());
    const claims = await m.verifyGoogleToken(body.credential, 'preview-client-id');
    if (!claims) {
      sendJson(401, { error: 'Invalid ID token' });
      return true;
    }
    const superadminEmail = process.env.SUPERADMIN_EMAIL ?? 'admin@example.com';
    const dbUser = await m.findOrCreateUser(repo, claims.email, superadminEmail);
    const rawSessionId = m.generateSessionId();
    const sessionHash = await m.hashSessionId(rawSessionId);
    const expiresAt = m.getSessionExpiry();
    await repo.createSession(sessionHash, dbUser.id, expiresAt);
    sendJson(200, { user: dbUser }, { 'Set-Cookie': m.buildSessionCookieHeader(rawSessionId, new Date(expiresAt)) });
    return true;
  }

  // POST /api/auth/logout
  if (url === '/api/auth/logout' && method === 'POST') {
    if (cookieHeader) {
      const cookies = m.parseCookies(cookieHeader);
      const sid = cookies[m.getSessionCookieName()];
      if (sid) {
        const sessionHash = await m.hashSessionId(sid);
        await repo.deleteSessionByHash(sessionHash);
      }
    }
    sendJson(200, { success: true }, { 'Set-Cookie': m.buildDeleteCookieHeader() });
    return true;
  }

  // POST /api/auth/request-admin
  if (url === '/api/auth/request-admin' && method === 'POST') {
    if (!user) {
      sendJson(401, { error: 'Not authenticated' });
      return true;
    }
    const result = await m.handleAdminAction({ repo, user }, { action: 'request_admin' });
    sendJson(result.success ? 200 : 403, result);
    return true;
  }

  // GET /api/admin/products
  if (url === '/api/admin/products' && method === 'GET') {
    if (!user) {
      sendJson(401, { error: 'Not authenticated' });
      return true;
    }
    if (!m.isApprovedAdmin(user)) {
      sendJson(403, { error: 'Forbidden' });
      return true;
    }
    const products = await repo.getAllProducts();
    sendJson(200, { products });
    return true;
  }

  // GET /api/admin/users
  if (url === '/api/admin/users' && method === 'GET') {
    if (!user) {
      sendJson(401, { error: 'Not authenticated' });
      return true;
    }
    if (!m.isApprovedAdmin(user)) {
      sendJson(403, { error: 'Forbidden' });
      return true;
    }
    const users = await repo.getAllUsers();
    const superadminCount = await repo.getSuperadminCount();
    sendJson(200, { users, superadminCount });
    return true;
  }

  // POST /api/admin/mutate
  if (url === '/api/admin/mutate' && method === 'POST') {
    const body = JSON.parse(await readBody());
    if (body.action && (body.action === 'ADD' || body.action === 'UPDATE' || body.action === 'DELETE')) {
      const result = await m.handleMutate({ repo, user }, body);
      sendJson(result.success ? 200 : 400, result);
      return true;
    }
    if (body.action && (body.action === 'approve_admin' || body.action === 'revoke_admin' || body.action === 'delete_admin_user' || body.action === 'request_admin')) {
      const result = await m.handleAdminAction({ repo, user }, body);
      sendJson(result.success ? 200 : 403, result);
      return true;
    }
    sendJson(400, { success: false, error: 'Unknown action' });
    return true;
  }

  // POST /api/checkout/create-order
  if (url === '/api/checkout/create-order' && method === 'POST') {
    if (!user) {
      sendJson(401, { error: 'not_authenticated' });
      return true;
    }
    let body: unknown;
    try {
      body = JSON.parse(await readBody());
    } catch {
      sendJson(400, { error: 'invalid_body' });
      return true;
    }
    try {
      const items = (body as { items?: { productId: string; quantity: number }[] })?.items ?? [];
      const shipping = (body as { shipping?: { name: string; phone: string; address: string } })?.shipping;
      const paymentMethod = (body as { paymentMethod?: string })?.paymentMethod ?? 'online';
      if (!items.length) {
        sendJson(400, { error: 'validation_failed', details: ['Cart is empty'] });
        return true;
      }
      if (!shipping?.name || !shipping?.phone || !shipping?.address) {
        sendJson(400, { error: 'validation_failed', details: ['Shipping details are required'] });
        return true;
      }
      if (paymentMethod !== 'online' && paymentMethod !== 'cod') {
        sendJson(400, { error: 'validation_failed', details: ['Invalid payment method'] });
        return true;
      }
      for (const item of items) {
        if (!item.productId || typeof item.quantity !== 'number' || item.quantity < 1 || item.quantity > 10) {
          sendJson(400, { error: 'validation_failed', details: ['Invalid item quantity'] });
          return true;
        }
        const product = await repo.getProductById(item.productId);
        if (!product) {
          sendJson(400, { error: 'unknown_product', productId: item.productId });
          return true;
        }
        if (!product.active) {
          sendJson(400, { error: 'inactive_product', productId: item.productId });
          return true;
        }
        if (product.stock_status === 'out_of_stock') {
          sendJson(409, { error: 'out_of_stock', productId: item.productId });
          return true;
        }
      }
      const productMap = new Map<string, { id: string; name: string; price_paise: number }>();
      for (const item of items) {
        if (!productMap.has(item.productId)) {
          const p = await repo.getProductById(item.productId);
          if (p) productMap.set(item.productId, p);
        }
      }
      const itemTotalPaise = items.reduce((sum, i) => sum + (productMap.get(i.productId)?.price_paise ?? 0) * i.quantity, 0);

      if (paymentMethod === 'cod') {
        const codEnabled = process.env.COD_ENABLED !== 'false';
        const { COD_FEE_PAISE, COD_MAX_ORDER_PAISE, isCodAvailable } = await import('@/lib/payments/config');
        if (!isCodAvailable(itemTotalPaise, codEnabled)) {
          sendJson(409, { error: 'cod_not_available' });
          return true;
        }
        const totalPaise = itemTotalPaise + COD_FEE_PAISE;
        const order = await repo.createOrder({
          userId: user.id,
          totalPaise,
          paymentMethod: 'cod',
          codFeePaise: COD_FEE_PAISE,
          shippingName: shipping.name,
          shippingPhone: shipping.phone,
          shippingAddress: shipping.address,
          items: items.map((i) => {
            const p = productMap.get(i.productId)!;
            return { productId: i.productId, nameSnapshot: p.name, pricePaiseSnapshot: p.price_paise, quantity: i.quantity };
          }),
        });
        sendJson(200, { orderId: order.id, paymentMethod: 'cod', amount: totalPaise, codFeePaise: COD_FEE_PAISE });
        return true;
      }

      const { provider, mode } = m.getPaymentProvider({ PAYMENT_MODE: process.env.PAYMENT_MODE });
      let providerOrderId: string;
      let keyId: string | undefined;
      try {
        const result = await provider.createOrder(itemTotalPaise, `order_${user.id}_${Date.now()}`);
        providerOrderId = result.providerOrderId;
        keyId = result.publicConfig.keyId;
      } catch (err) {
        const e = err as { code?: string };
        if (e?.code === 'payments_not_configured') {
          sendJson(503, { error: 'payments_not_configured' });
          return true;
        }
        sendJson(502, { error: 'provider_order_failed' });
        return true;
      }
      const order = await repo.createOrder({
        userId: user.id,
        totalPaise: itemTotalPaise,
        paymentMethod: 'online',
        codFeePaise: 0,
        providerOrderId,
        shippingName: shipping.name,
        shippingPhone: shipping.phone,
        shippingAddress: shipping.address,
        items: items.map((i) => {
          const p = productMap.get(i.productId)!;
          return { productId: i.productId, nameSnapshot: p.name, pricePaiseSnapshot: p.price_paise, quantity: i.quantity };
        }),
      });
      sendJson(200, { orderId: order.id, provider: mode, providerOrderId, amount: itemTotalPaise, currency: 'INR', keyId });
      return true;
    } catch (err) {
      console.error('mock checkout/create-order failed:', err);
      sendJson(500, { error: 'checkout_failed' });
      return true;
    }
  }

  // POST /api/checkout/mock-pay
  if (url === '/api/checkout/mock-pay' && method === 'POST') {
    if (m.resolvePaymentMode({ PAYMENT_MODE: process.env.PAYMENT_MODE }) !== 'mock') {
      sendJson(404, { error: 'not_found' });
      return true;
    }
    if (!user) {
      sendJson(401, { error: 'not_authenticated' });
      return true;
    }
    const body = JSON.parse(await readBody());
    const orderId = body?.orderId;
    const outcome = body?.outcome;
    if (!orderId || (outcome !== 'paid' && outcome !== 'failed')) {
      sendJson(400, { error: 'validation_failed', details: ['orderId and outcome are required'] });
      return true;
    }
    const order = await repo.getOrderById(orderId);
    if (!order) {
      sendJson(404, { error: 'order_not_found' });
      return true;
    }
    if (order.user_id !== user.id) {
      sendJson(403, { error: 'forbidden' });
      return true;
    }
    if (order.status !== 'created') {
      sendJson(409, { error: 'order_not_in_created_state', status: order.status });
      return true;
    }
    await repo.updateOrderStatus(orderId, outcome === 'paid' ? 'paid' : 'failed');
    sendJson(200, { orderId, status: outcome === 'paid' ? 'paid' : 'failed' });
    return true;
  }

  sendJson(404, { error: 'Not found' });
  return true;
}

export function apiMockPlugin(): Plugin {
  return {
    name: 'api-mock-plugin',
    apply: 'serve',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        const handled = await handleApiRoute(req, res).catch(() => false);
        if (!handled) next();
      });
    },
  };
}
