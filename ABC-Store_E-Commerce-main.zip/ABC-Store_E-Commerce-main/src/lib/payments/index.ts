import type { PaymentProvider, PaymentMode } from './provider';
import { MockPaymentProvider } from './mock';
import { RazorpayProvider } from './razorpay';

interface PaymentEnv {
  PAYMENT_MODE?: string;
  RAZORPAY_KEY_ID?: string;
  RAZORPAY_KEY_SECRET?: string;
}

export function resolvePaymentMode(env: PaymentEnv): PaymentMode {
  if (env.PAYMENT_MODE === 'mock') return 'mock';
  return 'razorpay';
}

export function getPaymentProvider(env: PaymentEnv): { provider: PaymentProvider; mode: PaymentMode } {
  const mode = resolvePaymentMode(env);
  if (mode === 'mock') {
    return { provider: new MockPaymentProvider(), mode };
  }
  return { provider: new RazorpayProvider(env), mode };
}
