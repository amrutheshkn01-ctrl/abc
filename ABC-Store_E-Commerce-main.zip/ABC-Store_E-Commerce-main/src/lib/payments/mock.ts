import type { PaymentProvider, CreateOrderResult } from './provider';
import { generateId } from '../utils';

export class MockPaymentProvider implements PaymentProvider {
  async createOrder(amountPaise: number, receipt: string): Promise<CreateOrderResult> {
    return {
      providerOrderId: `mock_${generateId()}`,
      publicConfig: {},
    };
  }
}
