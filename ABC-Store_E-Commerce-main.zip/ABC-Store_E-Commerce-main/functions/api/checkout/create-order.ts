// POST /api/checkout/create-order — create a provider order and persist it
import { z } from 'zod';
import { getRepository } from '../../../src/lib/db/index';
import { adaptEnv } from '../../../src/lib/env';
import { getUserFromRequest } from '../../../src/lib/auth/session';
import { getPaymentProvider } from '../../../src/lib/payments/index';
import { COD_FEE_PAISE, COD_MAX_ORDER_PAISE, isCodAvailable } from '../../../src/lib/payments/config';
import type { RazorpayNotConfiguredError } from '../../../src/lib/payments/razorpay';

interface Env {
  DB?: unknown;
  KV?: unknown;
  D1_DATABASE?: unknown;
  CATALOG_KV?: unknown;
  PAYMENT_MODE?: string;
  RAZORPAY_KEY_ID?: string;
  RAZORPAY_KEY_SECRET?: string;
  COD_ENABLED?: string;
  [key: string]: unknown;
}

const checkoutItemSchema = z.object({
  productId: z.string().min(1),
  quantity: z.number().int().min(1, 'Min 1 per item').max(10, 'Max 10 per item'),
});

const checkoutSchema = z.object({
  items: z.array(checkoutItemSchema).min(1, 'Cart is empty'),
  shipping: z.object({
    name: z.string().min(1, 'Name is required').max(200),
    phone: z.string().min(1, 'Phone is required').max(20),
    altPhone: z.string().max(20).optional(),
    address: z.string().min(1, 'Address is required').max(2000),
  }),
  paymentMethod: z.enum(['online', 'cod']).optional(),
});

export const onRequestPost: PagesFunction<Env> = async (context) => {
  const sendJson = (status: number, body: unknown) =>
    new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });

  try {
    const repo = getRepository(adaptEnv(context.env));
    const cookieHeader = context.request.headers.get('Cookie');
    const user = await getUserFromRequest(repo, cookieHeader);
    if (!user) {
      return sendJson(401, { error: 'not_authenticated' });
    }

    let body: unknown;
    try {
      body = await context.request.json();
    } catch {
      return sendJson(400, { error: 'invalid_body' });
    }

    const parsed = checkoutSchema.safeParse(body);
    if (!parsed.success) {
      return sendJson(400, { error: 'validation_failed', details: parsed.error.issues.map((i) => i.message) });
    }

    const { items, shipping, paymentMethod } = parsed.data;

    // Load products from D1 and validate every cart item
    const productMap = new Map<string, { id: string; name: string; price_paise: number; stock_status: string; active: boolean }>();
    for (const item of items) {
      if (!productMap.has(item.productId)) {
        const p = await repo.getProductById(item.productId);
        if (!p) {
          return sendJson(400, { error: 'unknown_product', productId: item.productId });
        }
        productMap.set(item.productId, p);
      }
    }

    for (const item of items) {
      const p = productMap.get(item.productId)!;
      if (!p.active) {
        return sendJson(400, { error: 'inactive_product', productId: item.productId });
      }
      if (p.stock_status === 'out_of_stock') {
        return sendJson(409, { error: 'out_of_stock', productId: item.productId });
      }
    }

    // Compute item total on the server from D1 prices (ignore any client fee/total)
    const itemTotalPaise = items.reduce((sum, i) => sum + productMap.get(i.productId)!.price_paise * i.quantity, 0);
    if (itemTotalPaise <= 0) {
      return sendJson(400, { error: 'invalid_total' });
    }

    const method = paymentMethod ?? 'online';
    const codEnabled = context.env.COD_ENABLED !== 'false';

    if (method === 'cod') {
      if (!isCodAvailable(itemTotalPaise, codEnabled)) {
        return sendJson(409, { error: 'cod_not_available' });
      }
      const totalPaise = itemTotalPaise + COD_FEE_PAISE;
      const order = await repo.createOrder({
        userId: user.id,
        totalPaise,
        paymentMethod: 'cod',
        codFeePaise: COD_FEE_PAISE,
        shippingName: shipping.name,
        shippingPhone: shipping.phone,
        shippingAltPhone: shipping.altPhone ?? null,
        shippingAddress: shipping.address,
        items: items.map((i) => {
          const p = productMap.get(i.productId)!;
          return { productId: i.productId, nameSnapshot: p.name, pricePaiseSnapshot: p.price_paise, quantity: i.quantity };
        }),
      });
      return sendJson(200, {
        orderId: order.id,
        paymentMethod: 'cod',
        amount: totalPaise,
        codFeePaise: COD_FEE_PAISE,
      });
    }

    // Online payment
    const { provider, mode } = getPaymentProvider(context.env as { PAYMENT_MODE?: string; RAZORPAY_KEY_ID?: string; RAZORPAY_KEY_SECRET?: string });
    let providerOrderId: string;
    let keyId: string | undefined;
    try {
      const result = await provider.createOrder(itemTotalPaise, `order_${user.id}_${Date.now()}`);
      providerOrderId = result.providerOrderId;
      keyId = result.publicConfig.keyId;
    } catch (err) {
      const e = err as RazorpayNotConfiguredError;
      if (e?.code === 'payments_not_configured') {
        console.error('checkout: payments not configured');
        return sendJson(503, { error: 'payments_not_configured' });
      }
      console.error('checkout: provider order failed:', err);
      return sendJson(502, { error: 'provider_order_failed' });
    }

    const order = await repo.createOrder({
      userId: user.id,
      totalPaise: itemTotalPaise,
      paymentMethod: 'online',
      codFeePaise: 0,
      providerOrderId,
      shippingName: shipping.name,
      shippingPhone: shipping.phone,
      shippingAltPhone: shipping.altPhone ?? null,
      shippingAddress: shipping.address,
      providerOrderId,
      amount: itemTotalPaise,
      currency: 'INR',
      keyId,
    });
  } catch (err) {
    console.error('checkout/create-order failed:', err);
    return sendJson(500, { error: 'checkout_failed' });
  }
};

// Suppress unused import warning for COD_MAX_ORDER_PAISE (kept for clarity/parity with config)
void COD_MAX_ORDER_PAISE;
