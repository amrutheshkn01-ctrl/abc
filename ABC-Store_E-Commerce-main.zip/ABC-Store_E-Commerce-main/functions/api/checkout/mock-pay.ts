// POST /api/checkout/mock-pay — simulate payment outcome (mock mode only)
import { z } from 'zod';
import { getRepository } from '../../../src/lib/db/index';
import { adaptEnv } from '../../../src/lib/env';
import { getUserFromRequest } from '../../../src/lib/auth/session';
import { resolvePaymentMode } from '../../../src/lib/payments/index';

interface Env {
  DB?: unknown;
  KV?: unknown;
  D1_DATABASE?: unknown;
  CATALOG_KV?: unknown;
  PAYMENT_MODE?: string;
  [key: string]: unknown;
}

const mockPaySchema = z.object({
  orderId: z.string().min(1),
  outcome: z.enum(['paid', 'failed']),
});

export const onRequestPost: PagesFunction<Env> = async (context) => {
  const sendJson = (status: number, body: unknown) =>
    new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });

  try {
    if (resolvePaymentMode(context.env as { PAYMENT_MODE?: string }) !== 'mock') {
      return sendJson(404, { error: 'not_found' });
    }

    const repo = getRepository(adaptEnv(context.env));
    const cookieHeader = context.request.headers.get('Cookie');
    const user = await getUserFromRequest(repo, cookieHeader);
    if (!user) {
      return sendJson(401, { error: 'not_authenticated' });
    }

    let body: unknown;
    try {
      body = await context.request.json();
    } catch {
      return sendJson(400, { error: 'invalid_body' });
    }

    const parsed = mockPaySchema.safeParse(body);
    if (!parsed.success) {
      return sendJson(400, { error: 'validation_failed', details: parsed.error.issues.map((i) => i.message) });
    }

    const { orderId, outcome } = parsed.data;

    const order = await repo.getOrderById(orderId);
    if (!order) {
      return sendJson(404, { error: 'order_not_found' });
    }
    if (order.user_id !== user.id) {
      return sendJson(403, { error: 'forbidden' });
    }
    if (order.status !== 'created') {
      return sendJson(409, { error: 'order_not_in_created_state', status: order.status });
    }

    const newStatus = outcome === 'paid' ? 'paid' : 'failed';
    await repo.updateOrderStatus(orderId, newStatus);

    return sendJson(200, { orderId, status: newStatus });
  } catch (err) {
    console.error('checkout/mock-pay failed:', err);
    return sendJson(500, { error: 'mock_pay_failed' });
  }
};
